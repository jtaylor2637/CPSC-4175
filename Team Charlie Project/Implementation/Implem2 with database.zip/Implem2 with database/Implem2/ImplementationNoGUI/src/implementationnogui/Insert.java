/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jtayl
 */
public class Insert {
 
    /**
     * Connect to the test.db database
     *
     * @return the Connection object
     */
    private Connection connect() {
        // SQLite connection string
        String url = "jdbc:sqlite:C:/Users/jtayl/Documents/Documents/CSU/Software Engineering/Project/sqlite-tools-win32-x86-3200100/pd.db";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
 
    /**
     * Insert a new row into the warehouses table
     *
     * @param name
     * @param capacity
     */
    public void insertUser(String userName, String userPass, String userAddress, float userBalance) {
        boolean uniq = true;
        String sq2 = "SELECT userName, userPass, userAddress, userBalance " + "FROM user WHERE userName = ?";
        
        try (Connection conn = this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sq2)) {
            pstmt.setString(1, userName);
           
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                uniq = false;
            } else {
                String sql = "INSERT INTO user(userName,userPass,userAddress, userBalance) VALUES(?,?,?,?)";
 
                try (Connection conn2 = this.connect();
                        PreparedStatement pstmt2 = conn2.prepareStatement(sql)) {
                    pstmt2.setString(1, userName);
                    pstmt2.setString(2, userPass);
                    pstmt2.setString(3, userAddress);
                    pstmt2.setFloat(4, userBalance);
                    pstmt2.executeUpdate();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch (SQLException e) {
                    System.out.println(e.getMessage());
        }
    }
    
    public void insertOrder(int orderId, String status, float cost) {
        boolean uniq = true;
        String sq2 = "SELECT orderId, status, cost " + "FROM orders WHERE orderId = ?";
        
        try (Connection conn = this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sq2)) {
            pstmt.setInt(1, orderId);
           
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                uniq = false;
                //System.out.println(rs.getInt("orderId"));
                //System.out.println(orderId);
                //System.out.println("duplicate order");
            } else {
                String sql = "INSERT INTO orders(orderId,status,cost) VALUES(?,?,?)";
 
                try (Connection conn2 = this.connect();
                        PreparedStatement pstmt2 = conn2.prepareStatement(sql)) {
                    pstmt2.setInt(1, orderId);
                    pstmt2.setString(2, status);           
                    pstmt2.setFloat(3, cost);
                    pstmt2.executeUpdate();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
    }
    
    public void insertTransaction(int transId, String userName, int orderId) {
        boolean uniq = true;
        String sq2 = "SELECT transId, userName, orderId " + "FROM transactions WHERE transId = ?";
        
        try (Connection conn = this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sq2)) {
            pstmt.setInt(1, transId);
           
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                uniq = false;
                //System.out.println("duplicate transaction");
            } else {
                String sql = "INSERT INTO transactions(transId,userName,orderId) VALUES(?,?,?)";

                try (Connection conn2 = this.connect();
                    PreparedStatement pstmt2 = conn2.prepareStatement(sql)) {
                    pstmt2.setInt(1, transId);
                    pstmt2.setString(2, userName);           
                    pstmt2.setInt(3, orderId);
                    pstmt2.executeUpdate();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
//        
        
        
    }
    /**
     * @param args the command line arguments
     */
    
 
}
