/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;

/**
 *
 * @author jtayl
 */
import java.util.ArrayList;

/**
 *
 * @author Team Charlie
 */
public class Cart
{
    private float total = 0;
    private int cartQuantity;
    private ArrayList<Item> itemsInCart;    
    
    public Cart(){
         //this.total = 0;
         itemsInCart = new ArrayList<Item>();
         itemsInCart.clear();
    }
    
    public float getTotal() {
        
        return total;
    }
    
    public void calcTotal(){
        if(total == 0){
            for(Item item : itemsInCart){           
                total += (item.getQuantity() * item.getPrice());
            }
        } else{
            total = 0;
            for(Item item : itemsInCart){
                //total += item.getPrice();
            total += (item.getQuantity() * item.getPrice());
        }
        }
        
    }
    
    public void setTotal(float total) {
        this.total = total;
    }
    
    public int getCartQuantity() {
        return itemsInCart.size();
    }
    
    public ArrayList<Item> getCart(){
        return itemsInCart;
    }
    
    public void setCartQuantity(int cartQuantity) {
        this.cartQuantity = cartQuantity;
    }
    
    public String getItemsInCart() {
        String list = "Items in Cart:\n";
        for(Item item : itemsInCart){
            list += item.cartDesc();
        }
        return list;
    }
        
    
    public boolean isEmpty() {
        if (itemsInCart.size() == 0) {
            return true;
        }
        else {
            return false;
        }
    }
    
    public void emptyCart() {
        System.out.println("Emptying Cart.\n");
        itemsInCart.clear();
        System.out.println("The cart is now empty.\n");
    }
    
    public void addItem(Item item){
        System.out.printf("Adding Item: %s to your cart.\n" , item.getName());
        itemsInCart.add(item);
        System.out.printf("Item: %s has been added to your cart.\n", item.getName());
    }
    
    public void removeItem(Item item) {
        System.out.printf("Removing Item: %s from your cart.\n" , item.getName());
        itemsInCart.remove(item);
        System.out.printf("Item: %s has been removed from your cart.\n", item.getName());
    }
    
    public void confirmCheckout() {
        System.out.println("Confirm your order?");
    }
    
    public void changeQuantity(Item item, int amount) {
        
        int ind = itemsInCart.indexOf(item);
        itemsInCart.get(ind).setQuantity(amount);
        //System.out.println("How many of the item would you like?");
    }
    
    public String orderString(){
        String order = "\n";
        for(Item item : itemsInCart ){
            order += ("Item Name: " + item.getName() + " - " + "Item Cost: " + item.getPrice() + "\n" );
        }
        return(order);
    }
    
    
}
