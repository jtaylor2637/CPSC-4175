/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author jtayl
 */
public class ImplementationNoGUI {
    
    public static void connect() {
        Connection conn = null;
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/Users/jtayl/Documents/Documents/CSU/Software Engineering/Project/sqlite-tools-win32-x86-3200100/pd.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.\n");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    
    public static void main(String[] args) {
        connect();
        User us1 = new User("SusanNichols", "24 Richard Lane", "Credit Card", "susan_nichols@gmail.com", "sn123", 600.0f);
        System.out.println(us1.toString());
        
        Insert tableInsert = new Insert();
        tableInsert.insertUser(us1.getUsername(), us1.getPass(), us1.getAddress(), us1.getBalance());
        
        
        
        
        
        //us1.addMoney(100);
        //System.out.println(us1.toString());         
        Item book1 = new Item("Object Oriented Design", 500.0f, "An intro to Object Oriented Design Principles", 001, 8, 1);
        //System.out.println(book1.toString());
        book1.setName("Advanced Object Oriented Design");
        System.out.println(book1.toString());
        Cart shoppingCart = new Cart();
        shoppingCart.addItem(book1);
        System.out.println(shoppingCart.getItemsInCart());
        shoppingCart.calcTotal();
        //System.out.println(shoppingCart.getTotal());
        //System.out.println(shoppingCart.orderString());
        
        
        Order thisOrder = new Order(shoppingCart, "Pending", 00001);
        thisOrder.displayOrder();
        System.out.println(thisOrder.getSummary());
        //System.out.println(thisOrder.getOrderCost());
        
        TransactionProcessor tp1 = new TransactionProcessor(1, us1, thisOrder);
        tp1.performTransaction();
        System.out.println(us1.toString());
        tp1.produceReport();
        
       
    }
    
}
