/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

import java.util.ArrayList;

/**
 *
 * @author Team Charlie
 */
public class Cart
{
    private float total;
    private int cartQuantity;
    private ArrayList<Item> itemsInCart;    
    

    public float getTotal() {
        for(Item item : itemsInCart){
           total += (item.getQuantity() * item.getPrice());
        }
        return total;
    }
    
    public void setTotal(float total) {
        this.total = total;
    }
    
    public int getCartQuantity() {
        return itemsInCart.size();
    }
    
    public void setCartQuantity(int cartQuantity) {
        this.cartQuantity = cartQuantity;
    }
    
    public String getItemsInCart() {
        String list = "";
        for(Item item : itemsInCart){
            list += item.cartDesc();
        }
        return list;
    }
        
    
    public boolean isEmpty() {
        if (itemsInCart.size() == 0) {
            return true;
        }
        else {
            return false;
        }
    }
    
    public void emptyCart() {
        itemsInCart.clear();
        System.out.println("The cart is now empty");
    }
    
    public void addItem(Item item){
        itemsInCart.add(item);
    }
    
    public void removeItem(Item item) {
        itemsInCart.remove(item);
        System.out.println("The item has been removed");
    }
    
    public void confirmCheckout() {
        System.out.println("Confirm your order?");
    }
    
    public void changeQuantity(Item item, int amount) {
        
        int ind = itemsInCart.indexOf(item);
        itemsInCart.get(ind).setQuantity(amount);
        //System.out.println("How many of the item would you like?");
    }
    
    
}
