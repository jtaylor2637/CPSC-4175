/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @authors: Team Charlie: Jacob Taylor and Tristan Porter
 * @version: 8/31/17
 * @description: User class
 */
public class User {
    private String userName;
    private String userAddress;
    private String paymentMethod;
    private String userPass;
    private String userEmail;
    private float userBalance;
    
    
    public User() {
        setUsername("default");
        setAddress("100 Road Avenue");
        setMethod("Credit");
        setPass("1234");
        setEmail("default@gmail.com");
        setBalance(100.00f);
    }
    
    public User(String user, String address, String method, String pass, String email, float balance) {
        setUsername(user);
        setAddress(address);
        setMethod(method);
        setPass(pass);
        setEmail(email);
        setBalance(balance);
    }
    
    public void setUsername(String name) {
        this.userName = name;
    }
    
    public String getUsername() {
        return(userName);
    }
    
    public void setAddress(String address) {
        this.userAddress = address;
    }
    
    public String getAddress() {
        return(userAddress);
    }
    
    public void setMethod(String method) {
        this.paymentMethod = method;
    }
    
    public String getMethod() {
        return(paymentMethod);
    }
    
    public void setPass(String pass) {
        this.userPass = pass;
    }
    
    public String getPass() {
        return(userPass);
    }
    
    public void setEmail(String email) {
        this.userEmail = email;
    }
    
    public String getEmail() {
        return(userEmail);
    }
    
    public void setBalance(float balance) {
        this.userBalance = balance;
    }
    
    public float getBalance() {
        return(userBalance);
    }
    
    public void viewCart(Cart cart){
        cart.getItemsInCart();
    }
    
    public void placeOrder(){
        //something
    }
    
    public void trackOrder(){
        //something
    }
    
    public void cancelOrder(){
        //something
    }
    
    public void viewOrder(Order order){
        order.displayOrder();
        order.getSummary();
    }
    
    public void selectCategory(){
        //something
    }
    
    public void addMoney(float amount){
        setBalance(getBalance() + amount);
    }
    
    
}
