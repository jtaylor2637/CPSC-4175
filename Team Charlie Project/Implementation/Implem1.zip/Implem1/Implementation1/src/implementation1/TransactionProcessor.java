/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @author taylor_jacob3
 */
public class TransactionProcessor {
    private String method;
    private int transNum;
    private User currentUser;
    private Order currentOrder;
    
    
    public void setUser(User user) {
        this.currentUser = user;
    }
    
    public User getUser() {
        return(currentUser);
    }
    
    public void setOrder(Order order){
        this.currentOrder = order;
    }
    
    public Order getOrder(){
        return(currentOrder);
    }
    
    public void setTransNum(int num){
        this.transNum = num;
    }
    
    public int getTransNum(){
        return(transNum);
    }
    
    public void produceReport(){
        //something
        System.out.println("User: " + getUser().getUsername() + "Order Number: " + getOrder().getOrderCost() + "Order Amount: " + getOrder().getOrderCost() + "Transaction Number: " + getTransNum());
    }
    
    public void performTransaction(){
        //something
    }
    
    public void storeTransaction(){
        //something
    }
}
