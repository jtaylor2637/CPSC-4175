/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @author Team Charlie
 */
public class Order
{
    private Cart orderedItems;
    private String status;
    private int orderNumber;
    private float orderCost;
    private String order;
    private String orderSummary;
    
    public Order(String status, int orderNumber, float orderCost, String order) {
        setStatus(status);
        setOrderNumber(orderNumber);
        setOrderCost(orderCost);
        setOrder(order);
    }

    public String getStatus(){
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    public float getOrderCost() {
        orderCost = orderedItems.getTotal();
        return orderCost;
    }
    
    public void setOrderCost(float orderCost) {
        this.orderCost = orderCost;
    }
    
    public String getOrder() {
        order = orderedItems.getItemsInCart();
        return order;
    }
    
    public void setOrder(String order) {
        this.order = order;
    }
    
    public void setSummary(String summ){
        this.orderSummary = summ;
    }
    
    public String getSummary(){
        return(orderSummary);
    }
    
    public void displayOrder() {
        setSummary("Here is your order information: \n" + "Order number: " + getOrder() + " Order Cost:" + getOrderCost() + " Order Status: " + getStatus() + " Order contains: " + getOrder() );
        //System.out.println("Here is your order information: ");
    }
    
    public void updateStatus(String newStatus) {
        status = newStatus;
    }
    
    public void storeOrder() {
        System.out.println("The order information has been stored for future reference");
    }
}
