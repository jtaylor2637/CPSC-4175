/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @authors: Team Charlie: Jacob Taylor and Tristan Porter
 * @version: 8/31/17
 * @description: item class
 */
public class Item {
    private String itemName;
    private float itemPrice;
    private String itemDescription;
    private int itemId;
    private int itemStock;
    private int itemQuantity;
    
    public void Item(){
        setName("Basic Book");
        setPrice(100.00f);
        setDesc("Just your average book");
        setId(001);
        setStock(8);
        setQuantity(1);
        
    }
    public void Item(String name, float price, String desc, int id, int stock, int quantity){
        setName(name);
        setPrice(price);
        setDesc(desc);
        setId(id);
        setStock(stock);
        setQuantity(quantity);
        
    }
    
    public void setName(String name) {
        this.itemName = name;
    }
    
    public String getName() {
        return(itemName);
    }
    
    public void setPrice(float price) {
        this.itemPrice = price;
    }
    
    public float getPrice() {
        return(itemPrice);
    }
    
    public void setDesc(String description) {
        this.itemDescription = description;
    }
    
    public String getDesc() {
        return(itemDescription);
    }
    
    public void setId(int id) {
        this.itemId = id;
    }
    
    public int getId(){
        return(itemId);
    }
    
    public void setStock(int stock) {
        this.itemStock = stock;
    }
    
    public int getStock(){
        return(itemStock);
    }
    
    public void setQuantity(int quantity) {
        this.itemQuantity = quantity;
    }
    
    public int getQuantity(){
        return(itemQuantity);
    }
    
    public String toString() {
        return("Book Title: " + getName() + "\nBook Price: " + getPrice() + "\nBook Description: " + getDesc() + "\nBook Id: " + getId() + "\nBook Stock: " + getStock() + "\nBook Quantity: " + getQuantity());
    }
    
    public String cartDesc(){
        return("Book Title: " + getName() + "\nBook Price: " + getPrice() + "\nBook Description: " + getDesc() + "\nBook Quantity: " + getQuantity());
    }
    
    
    
    
}
