/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 *
 * @author jtayl
 */
public class User {
    private String userName;
    private String userAddress;
    private String paymentMethod;
    private String userPass;
    private String userEmail;
    private float userBalance;
    private Cart userCart;
    private ArrayList<Order> orderList;
    private String uuid;
    
    public User() {
        setUsername("default");
        setAddress("100 Road Avenue");
        setMethod("Credit");
        setPass("1234");
        setEmail("default@gmail.com");
        setBalance(100.00f);
        setCart(new Cart());
        setOrderList(new ArrayList<Order>());
        setUUID();
    }
    
    public User(String user, String address, String method, String email, String pass, float balance) {
        setUsername(user);
        setAddress(address);
        setMethod(method);
        setEmail(email);
        setPass(pass);
        setBalance(balance);
        setCart(new Cart());
        setOrderList(new ArrayList<Order>());
        setUUID();
    }
    
    
    
    public void setOrderList(ArrayList<Order> orders){
        orderList = orders;
    }
    
    public ArrayList<Order> getOrderList(){
        return orderList;
    }
    
    public void addOrder(Order ord){
        
        orderList.add(ord);
    }
    
    public void removeOrder(Order ord){
        orderList.remove(ord);
    }
    
    public void updateOrder(Order ord, String stat){
               
        int found = orderList.indexOf(ord);
        orderList.get(found).setStatus(stat);
        
        
    }
    
    public String orderHistory(){
        if(orderList.isEmpty() == true){
            return ("You have not placed any orders yet.\n");
        } else {
            String orders = "\n";
            for(Order ord : orderList){
                ord.displayOrder();
                orders+= ord.getSummary() + "\n";
            }
            return orders;
        }
        
    }
    
    public void setUUID(){
        uuid = UUID.randomUUID().toString();
    }
    
    public String getUUID(){
        return uuid;
    }
    
    public void setCart(Cart cart){
        this.userCart = cart;
    }
    
    public Cart getCart(){
        return userCart;
    }
    
    public void setUsername(String name) {
        this.userName = name;
    }
    
    public String getUsername() {
        return(userName);
    }
    
    public void setAddress(String address) {
        this.userAddress = address;
    }
    
    public String getAddress() {
        return(userAddress);
    }
    
    public void setMethod(String method) {
        this.paymentMethod = method;
    }
    
    public String getMethod() {
        return(paymentMethod);
    }
    
    public void setPass(String pass) {
        this.userPass = pass;
    }
    
    public String getPass() {
        return(userPass);
    }
    
    public void setEmail(String email) {
        this.userEmail = email;
    }
    
    public String getEmail() {
        return(userEmail);
    }
    
    public void setBalance(float balance) {
        this.userBalance = balance;
    }
    
    public float getBalance() {
        return(userBalance);
    }
    
    public void viewCart(Cart cart){
        cart.getItemsInCart();
    }
    
    public void placeOrder(){
        //something
    }
    
    public void trackOrder(){
        //something
    }
    
    public void cancelOrder(){
        //something
    }
    
    public void viewOrder(Order order){
        order.displayOrder();
        order.getSummary();
    }
    
    public void selectCategory(){
        //something
    }
    
    public void addMoney(float amount){
        setBalance(getBalance() + amount);
    }
    
    public void payMoney(float amount){
        if(getBalance() >= amount){
            setBalance(getBalance() - amount);
        } else {
            System.out.println("Not enough money in account balance.");
        }
        
    }
    
    public String toString(){
        return("User Summary:\n" + "UserName: " + getUsername()+ "\nAddress: " + getAddress() + "\nPayment Method: " + getMethod() + "\nEmail: " + getEmail() + "\nPassword: " + getPass() + "\nBalance: " + getBalance() +"\n");
    }
    
}

