/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;

/**
 *
 * @author jtayl
 */
import java.util.ArrayList;

/**
 *
 * @author Team Charlie
 */
public class Cart
{
    private float total = 0;
    private int cartQuantity;
    private ArrayList<Item> itemsInCart;    
    
    public Cart(){
         //this.total = 0;
         itemsInCart = new ArrayList<Item>();
         itemsInCart.clear();
    }
    
    public float getTotal() {
        
        return total;
    }
    
    public void calcTotal(){
        if(total == 0){
            for(Item item : itemsInCart){           
                total += (item.getQuantity() * item.getPrice());
            }
        } else{
            total = 0;
            for(Item item : itemsInCart){
                //total += item.getPrice();
            total += (item.getQuantity() * item.getPrice());
        }
        }
        
    }
    
    public int calcTotalItems(){
        int totalItems = 0;
        for(Item item : itemsInCart){
            totalItems += (item.getQuantity());
        }
        
        return totalItems;
    }
    
    
    
    public void setTotal(float total) {
        this.total = total;
    }
    
    public int getCartQuantity() {
        return itemsInCart.size();
    }
    
    public ArrayList<Item> getCart(){
        return itemsInCart;
    }
    
    public void setCartQuantity(int cartQuantity) {
        this.cartQuantity = cartQuantity;
    }
    
    public String getItemsInCart() {
        String list = "Items in Cart:\n";
        for(Item item : itemsInCart){
            list += item.cartDesc();
        }
        return list;
    }
        
    
    public boolean isEmpty() {
        if (itemsInCart.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }
    
    public boolean containsItem(Item item){
        if(itemsInCart.contains(item)){
            
            return true;
        } else {
            return false;
        }
    }
    
    public Item containsItemWithId(int id){
        for(Item item : itemsInCart){
            if(item.getId() == id){
                return item;
            }
        }
        return null;
    }
    
    
    public void emptyCart() {
        System.out.println("Emptying Cart.\n");
        itemsInCart.clear();
        System.out.println("The cart is now empty.\n");
    }
    
    public void addItem(Item item){
        System.out.printf("Adding Item: %s to your cart.\n" , item.getName());
        itemsInCart.add(item);
        System.out.printf("Item: %s has been added to your cart.\n", item.getName());
    }
    
    public void removeItem(Item item) {
        System.out.printf("Removing Item: %s from your cart.\n" , item.getName());
        itemsInCart.remove(item);
        System.out.printf("Item: %s has been removed from your cart.\n", item.getName());
    }
    
    public int totalUniqueItems(){
        return itemsInCart.size();
    }
    
    public void confirmCheckout() {
        System.out.println("Confirm your order?");
    }
    
    public void changeQuantity(Item item, int amount) {
        
        int ind = itemsInCart.indexOf(item);
        itemsInCart.get(ind).setQuantity(amount);
        System.out.println("You have changed " + item.getName() +"'s quantity to " + item.getQuantity() +".\n");
        //System.out.println("How many of the item would you like?");
    }
    
    public void increaseQuantity(Item item) {
        
        int ind = itemsInCart.indexOf(item);
        itemsInCart.get(ind).increaseQuantity();
        //System.out.println("How many of the item would you like?");
    }
    
    public void decreaseQuantity(Item item) {
        
        int ind = itemsInCart.indexOf(item);
        itemsInCart.get(ind).decreaseQuantity();
        //System.out.println("How many of the item would you like?");
    }
    
    public String orderString(){
        String order = "\n";
        for(Item item : itemsInCart ){
            order += ("Item Name: " + item.getName() + " - " + "Item Cost: " + item.getPrice() + "\n" );
        }
        return(order);
    }
    
    public String cartString(){
        if(itemsInCart.isEmpty() == true){
            String emp = "Your cart is currently empty.";
            return emp;
        } else {
            String items = "\nYour cart currently contains:\n";
            for(Item item : itemsInCart){
                //items += ("Item Name")
                items += item.toString() + "\n";
            }
            return items;
        }
        
    }
    
}
