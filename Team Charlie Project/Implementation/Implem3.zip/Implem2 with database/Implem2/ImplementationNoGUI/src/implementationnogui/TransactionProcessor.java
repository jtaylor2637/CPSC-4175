/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;

import java.util.UUID;

/**
 *
 * @author jtayl
 */
public class TransactionProcessor {
    private static int count = 0;
    private int transNum;
    private User currentUser;
    private Order currentOrder;
    private String uuid;
    public TransactionProcessor(User current, Order order){
        setTransNum(++count);
        setUser(current);
        setOrder(order);
        setUUID();
    }
    
    public void setUser(User user) {
        this.currentUser = user;
    }
    
    public void setUUID(){
        uuid = UUID.randomUUID().toString();
    }
    
    public String getUUID(){
        return uuid;
    }
    
    public User getUser() {
        return(currentUser);
    }
    
    public void setOrder(Order order){
        this.currentOrder = order;
    }
    
    public Order getOrder(){
        return(currentOrder);
    }
    
    public void setTransNum(int num){
        this.transNum = num;
    }
    
    public int getTransNum(){
        return(transNum);
    }
    
    public void produceReport(){
        System.out.println("Transaction Summary:\n" + "User: " + getUser().getUsername() + "\nOrder Number: " + getOrder().getOrderNumber()+ "\nOrder Amount: " + getOrder().getOrderCost() + "\nTransaction Number: " + getTransNum() + "\n");
         
    }
    
    public void performTransaction(){
        if(currentUser.getBalance() > currentOrder.getOrderCost()){
            produceReport();
            currentUser.payMoney(currentOrder.getOrderCost());
            getOrder().getOrderCart().emptyCart();
            storeTransaction();
            getOrder().storeOrder();
            currentUser.addOrder(currentOrder);
        } else {
            System.out.println("Not enough money in balance for this order, please add more funds to purchase.");
        }
        //something
    }
    
    public void storeTransaction(){
        Insert inserter = new Insert();
        System.out.println(getUUID());
        inserter.insertTransaction(getTransNum(), this.currentUser.getUsername(), this.currentOrder.getOrderNumber(), getUUID());
        System.out.println("Stored Transaction\n");//something
    }
}