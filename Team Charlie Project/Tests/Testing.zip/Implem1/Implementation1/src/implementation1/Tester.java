/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @author taylor_jacob3
 */
public class Tester {
    public static void main(String[] args){
        User us1 = new User("Susan Nichols", "24 Richard Lane", "Credit Card", "susan_nichols@gmail.com", "sn123", 340.0f);
        System.out.println(us1.toString());
        
    }
}
