/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @author taylor_jacob3
 */
public class TransactionProcessor {
    
    private int transNum;
    private User currentUser;
    private Order currentOrder;
    
    public TransactionProcessor(int num, User current, Order order){
        setTransNum(num);
        setUser(current);
        setOrder(order);
    }
    
    public void setUser(User user) {
        this.currentUser = user;
    }
    
    public User getUser() {
        return(currentUser);
    }
    
    public void setOrder(Order order){
        this.currentOrder = order;
    }
    
    public Order getOrder(){
        return(currentOrder);
    }
    
    public void setTransNum(int num){
        this.transNum = num;
    }
    
    public int getTransNum(){
        return(transNum);
    }
    
    public void produceReport(){
        if(currentUser.getBalance() > currentOrder.getOrderCost()){
            System.out.println("Transaction Summary:\n" + "User: " + getUser().getUsername() + "\nOrder Number: " + getOrder().getOrderNumber()+ "\nOrder Amount: " + getOrder().getOrderCost() + "\nTransaction Number: " + getTransNum() + "\n");
        } else {
            System.out.println("Not enough money in balance for this order, please add more funds to purchase. No transactions occurred");
        }
        
        
    }
    
    public void performTransaction(){
        if(currentUser.getBalance() > currentOrder.getOrderCost()){
            currentUser.payMoney(currentOrder.getOrderCost());
        } else {
            System.out.println("Not enough money in balance for this order, please add more funds to purchase.");
        }
        //something
    }
    
    public void storeTransaction(){
        //something
    }
}
