/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Jacob Taylor and Tristan
 */
public class Implementation1 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
        
        StackPane root = new StackPane();
        root.getChildren().add(btn);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        User us1 = new User("SusanNichols", "24 Richard Lane", "Credit Card", "susan_nichols@gmail.com", "sn123", 340.0f);
        System.out.println(us1.toString());
        us1.addMoney(100);
        System.out.println(us1.toString());
        Item book1 = new Item("Object Oriented Design", 500.0f, "An intro to Object Oriented Design Principles", 001, 8, 1);
        System.out.println(book1.toString());
        book1.setName("Advanced Object Oriented Design");
        System.out.println(book1.toString());
        Cart shoppingCart = new Cart();
        shoppingCart.addItem(book1);
        System.out.println(shoppingCart.getItemsInCart());
        shoppingCart.calcTotal();
        //System.out.println(shoppingCart.getTotal());
        //System.out.println(shoppingCart.orderString());
        
        
        Order thisOrder = new Order(shoppingCart, "Pending", 00001);
        thisOrder.displayOrder();
        System.out.println(thisOrder.getSummary());
        //System.out.println(thisOrder.getOrderCost());
        
        TransactionProcessor tp1 = new TransactionProcessor(1, us1, thisOrder);
        tp1.performTransaction();
        System.out.println(us1.toString());
        tp1.produceReport();
    }
    
}
