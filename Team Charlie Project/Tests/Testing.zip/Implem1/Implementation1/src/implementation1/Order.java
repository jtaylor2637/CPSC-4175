/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation1;

/**
 *
 * @author Team Charlie
 */
public class Order
{
    private Cart orderedItems;
    private String status;
    private int orderNumber;
    private float orderCost;
    private String order;
    private String orderSummary;
    
    public Order(Cart orderCart, String status, int orderNumber) {
        setOrderCart(orderCart);
        setStatus(status);
        setOrderNumber(orderNumber);
        
        //setOrderCost(orderCost);
        //setOrder(order);
    }

    public String getStatus(){
        return status;
    }
    
    public Cart getOrderCart(){
        return orderedItems;
    }
    
    public void setOrderCart(Cart cart){
        this.orderedItems = cart;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    public float getOrderCost() {
        //orderCost = orderedItems.getTotal();
        return orderedItems.getTotal();
    }
    
    //public void setOrderCost(float orderCost) {
        //this.orderCost = orderCost;
    //}
    
    public String getOrder() {
        return(orderedItems.orderString());
        //order = "";
        //for(Item item : orderedItems.getCart()){
        //    order += (item.getName() + " " + item.getPrice() +"\n" );
        //}
        
        //return order;
    }
    
   // public void setOrder(Cart order) {
       // this.order = order.getItemsInCart();
   // }
    
    public void setSummary(String summ){
        this.orderSummary = summ;
    }
    
    public String getSummary(){
        return(orderSummary);
    }
    
    public void displayOrder() {
        setSummary("Here is your order information: \n" + "Order number: " + getOrderNumber() + "\nOrder Cost: " + getOrderCost() + "\nOrder Status: " + getStatus() + "\nOrder contains: " + getOrder() + "\n" );
        //System.out.println("Here is your order information: ");
    }
    
    public void updateStatus(String newStatus) {
        status = newStatus;
    }
    
    public void storeOrder() {
        System.out.println("The order information has been stored for future reference");
    }
}
