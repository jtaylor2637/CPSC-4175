/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationnogui;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author jtayl
 */
public class ImplementationNoGUI {
    
    public static void connect() {
        Connection conn = null;
        try {
            // db parameters
            String schoolurl = "jdbc:sqlite:H:/Software Engineering/Project/Implem3/Implem2 with database/sqlite-tools-win32-x86-3200100/pd.db";
            String homeurl = "jdbc:sqlite:C:/Users/jtayl/Documents/Documents/CSU/Software Engineering/Project/Implem3/Implem2 with database/sqlite-tools-win32-x86-3200100/pd.db";
            // create a connection to the database
            conn = DriverManager.getConnection(schoolurl);
            
            System.out.println("Connection to SQLite has been established.\n");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    
    public static int displayMenu(boolean auto){
        ArrayList<Integer> choices = new ArrayList<Integer>();
        choices.add(1);
        choices.add(2);
        choices.add(3);
        choices.add(4);
        choices.add(5);
        choices.add(6);
        choices.add(7);
        Scanner scan = new Scanner(System.in);
        int userChoice = 0;
        int count = 0;
        do{
            if(count != 0){
                System.out.println("Please only input a valid choice 1-6!");
            }
            System.out.println("Welcome to the main menu!");
            System.out.println("Enter 1 to view available items from the store.");
            System.out.println("Enter 2 to add an item to your cart");
            System.out.println("Enter 3 to view your cart.");
            System.out.println("Enter 4 to view / edit your personal information.");
            System.out.println("Enter 5 to view your past orders.");
            System.out.println("Enter 6 to add money to your account.");
            System.out.println("Enter 7 to log out of the store and exit.");
            System.out.println("What would you like to do? ");
            if(auto == false){
                try {
                    userChoice = scan.nextInt();
                } catch(InputMismatchException e) {
                    System.out.println("Invalid input type!");
                    break;
                } 
            } else {
                break;
            }
            
            
            count++;
        } while(choices.contains(userChoice) == false);
        return userChoice;
        
    }
    
    public static void displayItems(ArrayList<Item> items){
        System.out.println("Items available in the store at the moment are...");
        for(int i = 0; i < items.size(); i++){
            System.out.println("Item " + (i+1) +"\n");
            System.out.println(items.get(i).toString());
            System.out.println();
        }
    }
    
    public static void addItemToCart(ArrayList<Item> items, Cart userCart, boolean auto){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the item id of the item you would like to add to your cart.");
        //int selected;
        boolean found = false;
        Item desired;
        if(auto == false){            
        
            try {
                int userChoice = scan.nextInt();
                System.out.println();
                for(int i = 0; i < items.size(); i++){
                    if(items.get(i).getId() == userChoice){
                        //selected = i;
                        desired = items.get(i);
                        found = true;
                        if(userCart.containsItem(desired)) {
                            System.out.println("Another copy of " + desired.getName() + " has been added to your cart.");
                            userCart.increaseQuantity(desired);
                        } else {
                            userCart.addItem(desired);
                        }

                        //System.out.println("We made it");
                    }
                }
                if(found == false){
                    System.out.println("Item Id not found");
                }
            } catch(InputMismatchException e) {
                System.out.println("Invalid input type!");
            }
        } else {
            desired = items.get(0);
            if(userCart.containsItem(desired)) {
                System.out.println("Another copy of " + desired.getName() + " has been added to your cart.");
                userCart.increaseQuantity(desired);
            } else {
                userCart.addItem(desired);
            }
        }
        
    }
    
    public static void removeItemFromCart(Cart userCart, boolean auto){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the item id of the item you would like to remove from your cart.");
        //int selected;
        boolean found = false;
        Item desired;
        
        if(auto == false){
                    
            try {
                int userChoice = scan.nextInt();
                System.out.println();
                desired = userCart.containsItemWithId(userChoice);

                if(desired == null){
                    found = false;                    
                } else {
                    found = true;
                    userCart.removeItem(desired);

                }

                if(found == false){
                    System.out.println("Item Id not found");
                }
            } catch(InputMismatchException e) {
                System.out.println("Invalid input type!");
            }
        } else {
            //System.out.println("Enter the item id of the item you would like to remove from your cart.");
            desired = userCart.containsItemWithId(1);
            userCart.removeItem(desired);
        }
        
    }
    
    
    public static void changeItemQuantity(Cart userCart, boolean auto){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the item id of the item you would like to change the quantity of.");
        boolean found = false;
        Item desired;
        if(auto == false){
                    
            try {
                int userChoice = scan.nextInt();
                System.out.println();
                desired = userCart.containsItemWithId(userChoice);

                if(desired == null){
                    found = false;                    
                } else {
                    found = true;
                    System.out.println("Enter the amount of the item you would like to change the quantity to.");
                    try {
                        int amount = scan.nextInt();
                        System.out.println();
                        userCart.changeQuantity(desired, amount);
                    } catch(InputMismatchException e){
                        System.out.println("Invalid input type!");
                    }


                }

                if(found == false){
                    System.out.println("Item Id not found");
                }
            } catch(InputMismatchException e) {
                System.out.println("Invalid input type!");
            }
        } else {
            //System.out.println("Enter the item id of the item you would like to change the quantity of.");
            desired = userCart.containsItemWithId(1);
            System.out.println("Enter the amount of the item you would like to change the quantity to.");
            userCart.changeQuantity(desired, 2);
        }
        
    }
    
    
    
    
    public static void editCart(ArrayList<Item> items, Cart userCart, boolean auto){
        ArrayList<Integer> choices = new ArrayList<Integer>();
        choices.add(1);
        choices.add(2);
        choices.add(3);
        choices.add(4);
        
        
        if(auto == false){            
        
            Scanner scan = new Scanner(System.in);
            int userChoice = 0;
            int count = 0;
            do{
                if(count != 0){
                    System.out.println("Please only input a valid choice 1-4!");
                }
                System.out.println("Cart editing menu");
                System.out.println("Enter 1 to remove an item from the cart.");
                System.out.println("Enter 2 to add an item to your cart.");
                System.out.println("Enter 3 to change the quantity of an item in the cart.");
                System.out.println("Enter 4 to cancel editing.");
                System.out.println("What would you like to do? ");
                try {
                    userChoice = scan.nextInt();
                    switch(userChoice){
                        case 1:
                            System.out.println(userCart.cartString());
                            userCart.calcTotal();
                            System.out.println("Total Cost: " + userCart.getTotal());
                            removeItemFromCart(userCart, auto);
                            break;
                        case 2:
                            System.out.println(userCart.cartString());
                            userCart.calcTotal();
                            System.out.println("Total Cost: " + userCart.getTotal());
                            addItemToCart(items, userCart, auto);
                            break;
                        case 3:
                            System.out.println(userCart.cartString());
                            userCart.calcTotal();
                            System.out.println("Total Cost: " + userCart.getTotal());
                            changeItemQuantity(userCart, auto);
                            break;
                        case 4:
                            break;
                        default:
                            System.out.println("Incorrect input!");
                            break;
                    }
                } catch(InputMismatchException e) {
                    System.out.println("Invalid input type!");
                    break;
                }

                count++;
            } while(choices.contains(userChoice) == false);
        } else {
            System.out.println("Cart editing menu");
            System.out.println("Enter 1 to remove an item from the cart.");
            System.out.println("Enter 2 to add an item to your cart.");
            System.out.println("Enter 3 to change the quantity of an item in the cart.");
            System.out.println("Enter 4 to cancel editing.");
            System.out.println("What would you like to do? ");
            removeItemFromCart(userCart, auto);
            System.out.println();
            addItemToCart(items, userCart, auto);
            System.out.println();
            changeItemQuantity(userCart, auto);
            System.out.println();
        }
    }
    
    
    public static void createOrder(User us1, Cart userCart){
        userCart.calcTotal();
        if(us1.getBalance() < userCart.getTotal()){
            System.out.println("Your balance is: " + us1.getBalance());
            System.out.println("The order costs: " + userCart.getTotal());
            System.out.println("You do not have enough funds for this purchase.");
            
        } else {
            Order ord = new Order(userCart, "pending");
            TransactionProcessor tp1 = new TransactionProcessor(us1, ord);
            ord.setOrderContents(userCart.orderString());
            tp1.performTransaction();
            System.out.println("Order processed and payment recieved, order added to order history.\n");
            us1.updateOrder(ord, "shipping");
            
        }
        
        
        
    }
    
    
    public static void viewCart(ArrayList<Item> items, Cart userCart, User us1, boolean auto){
        System.out.println(userCart.cartString());
        userCart.calcTotal();
        System.out.println("Total Cost: " + userCart.getTotal());
        
        if(auto == false){
                    
            Scanner scan = new Scanner(System.in);
            int userChoice = 0;
            int count = 0;
            if(userCart.isEmpty() == false){
                while((userChoice != 1 || userChoice != 2) && userCart.isEmpty() == false){
                    if(count != 0){
                        System.out.println(userCart.cartString());
                        userCart.calcTotal();
                        System.out.println("Total Cost: " + userCart.getTotal());
                    }
                    count++;
                    System.out.println("\nWould you like to edit your cart?\nEnter 1 for Yes and 2 for No.\n");
                    try {
                        userChoice = scan.nextInt();
                        if(userChoice == 2){
                            break;
                        } else if (userChoice == 1){
                            editCart(items, userCart, auto);
                        } else {
                            System.out.println("Invalid choice!");
                        }
                    } catch(InputMismatchException e) {
                        System.out.println("Invalid input type!");
                    }
                }

                userChoice = 0;
                count = 0;

                while((userChoice != 1 || userChoice != 2) && userCart.isEmpty() == false){
                    if(count != 0){
                        System.out.println(userCart.cartString());
                        userCart.calcTotal();
                        System.out.println("Total Cost: " + userCart.getTotal());
                    }
                    count++;
                    System.out.println("\nWould you like to purchase everything in your cart?\nEnter 1 for Yes and 2 for No.\n");
                    try {
                        userChoice = scan.nextInt();
                        if(userChoice == 2){
                            break;
                        } else if (userChoice == 1){
                            createOrder(us1, userCart);
                        } else {
                            System.out.println("Invalid choice!");
                        }
                    } catch(InputMismatchException e) {
                        System.out.println("Invalid input type!");
                    }
                }

            }
        } else {
            
            
            System.out.println("\nWould you like to edit your cart?\nEnter 1 for Yes and 2 for No.\n");
            editCart(items, userCart, auto);
            
            System.out.println(userCart.cartString());
            userCart.calcTotal();
            System.out.println("Total Cost: " + userCart.getTotal());
            
            System.out.println("\nWould you like to purchase everything in your cart?\nEnter 1 for Yes and 2 for No.\n");
            createOrder(us1, userCart);
        }
        
        
    }
    
    public static void changeUserAttribute(User us1, int choice){
        System.out.println(us1.toString());
        System.out.println();
        Scanner scan = new Scanner(System.in);
        String update;
        switch(choice){
            case 1:
                System.out.println("Enter your new address.");
                try {
                    update = scan.nextLine();
                    us1.setAddress(update);
                    System.out.println("Information updated.");
                    break;
                } catch(InputMismatchException e) {
                    System.out.println("Invalid input type!");
                }
                
            case 2:
                System.out.println("Enter your new password.");
                try {
                    update = scan.nextLine();
                    us1.setPass(update);
                    System.out.println("Information updated.");
                    break;
                } catch(InputMismatchException e) {
                    System.out.println("Invalid input type!");
                }
            case 3:
                System.out.println("Enter your new email.");
                try {
                    update = scan.nextLine();
                    us1.setEmail(update);
                    System.out.println("Information updated.");
                    break;
                } catch(InputMismatchException e) {
                    System.out.println("Invalid input type!");
                }
            default:
                break;
        }
    }
    
    
    public static void editUserInfo(User us1, boolean auto){
        System.out.println(us1.toString());
        
        Scanner scan = new Scanner(System.in);
        int userChoice = 0;
        int count = 0;
        int userChoice2 = 0;
        ArrayList<Integer> choices = new ArrayList<Integer>();
        choices.add(1);
        choices.add(2);
        choices.add(3);
        choices.add(4);
        
        if(auto == false){         
                
            while((userChoice != 1 || userChoice != 2))
            {

                    System.out.println("\nWould you like to edit your user info?\nEnter 1 for Yes and 2 for No.\n");
                    try {
                        userChoice = scan.nextInt();
                        if(userChoice == 2){
                            break;
                        } else if (userChoice == 1){
                            do{
                                if(count != 0){
                                    System.out.println("Please only input a valid choice 1-4!");
                                }
                                System.out.println("User editing menu");
                                System.out.println("Enter 1 for address.");
                                System.out.println("Enter 2 for password.");
                                System.out.println("Enter 3 for email.");
                                System.out.println("Enter 4 to cancel.");
                                System.out.println("What would you like to do? ");
                                try {
                                    userChoice2 = scan.nextInt();
                                    switch(userChoice2){
                                        case 1:
                                            changeUserAttribute(us1, 1);
                                            break;
                                        case 2:
                                            changeUserAttribute(us1, 2);
                                            break;
                                        case 3:
                                            changeUserAttribute(us1, 3);
                                            break;
                                        case 4:
                                            break;
                                        default:
                                            System.out.println("Incorrect input!");
                                            break;
                                    }
                                } catch(InputMismatchException e) {
                                    System.out.println("Invalid input type!");
                                    break;
                                }
                                count++;
                            } while(choices.contains(userChoice2) == false);




                        } else {
                            System.out.println("Invalid choice!");
                        }
                    } catch(InputMismatchException e) {
                        System.out.println("Invalid input type!");
                    }
            }
        } else{
            System.out.println("User editing menu");
            System.out.println("Enter 1 for address.");
            System.out.println("Enter 2 for password.");
            System.out.println("Enter 3 for email.");
            System.out.println("Enter 4 to cancel.");
            System.out.println("What would you like to do? ");
            
            us1.setAddress("AutomatedTesting Lane");
            us1.setPass("autobots");
            us1.setEmail("auto@auto.org");
            
            System.out.println(us1.toString());
        }
        
    }
    
    
    public static void displayOrderHistory(User us1){
        System.out.println(us1.orderHistory());
    }
    
    public static void addMoneyToUser(User us1, boolean auto){
        Scanner scan = new Scanner(System.in);
        int userChoice = 0;
        float userChoice2;
        int count = 0;
        if(auto == false){                   
        
            while((userChoice != 1 || userChoice != 2))
            {
                    System.out.println("\nWould you like to add more funds?\nEnter 1 for Yes and 2 for No.\n");
                    try {
                        userChoice = scan.nextInt();
                        if(userChoice == 2){
                            break;
                        } else if (userChoice == 1){
                            System.out.println("How much would you like to add?");
                            try {
                                userChoice2 = scan.nextFloat();
                                if(userChoice2 > 0){
                                    us1.addMoney(userChoice2);
                                    System.out.println("You have added " + userChoice2 + " dollars to your account.");
                                    System.out.println("New balance: " + us1.getBalance());
                                } else {
                                    System.out.println("Invalid amount!");
                                }
                            } catch(InputMismatchException e){
                                System.out.println("Invalid input type!");
                            }
                        } else {
                            System.out.println("Invalid choice!");
                        }
                    } catch(InputMismatchException e) {
                        System.out.println("Invalid input type!");
                    }
            }
        } else {
            System.out.println("\nWould you like to add more funds?\nEnter 1 for Yes and 2 for No.\n");
            us1.addMoney(2000);
            System.out.println("You have added " + 2000 + " dollars to your account.");
            System.out.println("New balance: " + us1.getBalance());
        }
    }
    
    
    public static void main(String[] args) {
        ArrayList<Item> items = new ArrayList<Item>();
        Item book1 = new Item("Object Oriented Design", 500.0f, "An intro to Object Oriented Design Principles", 1, 20, 1);
        Item book2 = new Item("Mathematics for Dummies", 250.0f, "2 + 2 = Fish", 2, 20, 1);
        Item book3 = new Item("Speaking English as a American", 125.0f, "When to use their, there, or they're", 3, 20, 1);
        Item book4 = new Item("Historically Speaking", 420.0f, "A exploration of the world through time", 4, 20, 1);
        Item book5 = new Item("Let's get Physical", 180.0f, "All you wanted to know about thrust, friction, heat, and motion", 5, 20, 1);
        items.add(book1);
        items.add(book2);
        items.add(book3);
        items.add(book4);
        items.add(book5);
        
        
        connect();
        User us1 = new User("SusanNichols", "24 Richard Lane", "Credit Card", "susan_nichols@gmail.com", "sn123", 600.0f);
        
        
        Insert tableInsert = new Insert();
        tableInsert.insertUser(us1.getUsername(), us1.getPass(), us1.getAddress(), us1.getBalance());
        
        //automatic tester, comment these lines and uncomment the user tester for application use
        displayMenu(true);
        System.out.println();
        displayItems(items);
        System.out.println();
        addItemToCart(items, us1.getCart(), true);
        System.out.println();
        viewCart(items, us1.getCart(), us1, true);
        System.out.println();
        editUserInfo(us1, true);
        System.out.println();
        displayOrderHistory(us1);
        System.out.println();
        addMoneyToUser(us1, true);
        System.out.println();
        createOrder(us1, us1.getCart());
        System.out.println();
        displayOrderHistory(us1);
       









//real user tester
        /*
        boolean done = false;
        while(done == false){
            int choice = displayMenu(false);
            System.out.println();
            switch(choice){
                case 1:
                    displayItems(items);
                    System.out.println("\nGoing back to main menu...\n");
                    break;
                case 2:
                    addItemToCart(items, us1.getCart());
                    System.out.println("\nGoing back to main menu...\n");
                    break;
                case 3:
                    viewCart(items, us1.getCart(), us1);
                    System.out.println("\nGoing back to main menu...\n");
                    break;
                case 4:
                    editUserInfo(us1);
                    break;
                case 5:
                    displayOrderHistory(us1);
                    break;
                case 6:
                    addMoneyToUser(us1);
                    break;
                case 7:
                    done = true;
                    //System.out.println();
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("unrecognized input! exiting program");
                    break;
            }
        } */
        
        
        /*
        connect();
        User us1 = new User("SusanNichols", "24 Richard Lane", "Credit Card", "susan_nichols@gmail.com", "sn123", 600.0f);
        System.out.println(us1.toString());
        
        Insert tableInsert = new Insert();
        tableInsert.insertUser(us1.getUsername(), us1.getPass(), us1.getAddress(), us1.getBalance());
        
        
        
        
        
        //us1.addMoney(100);
        //System.out.println(us1.toString());         
        Item book1 = new Item("Object Oriented Design", 500.0f, "An intro to Object Oriented Design Principles", 001, 8, 1);
        //System.out.println(book1.toString());
        book1.setName("Advanced Object Oriented Design");
        System.out.println(book1.toString());
        Cart shoppingCart = new Cart();
        shoppingCart.addItem(book1);
        System.out.println(shoppingCart.getItemsInCart());
        shoppingCart.calcTotal();
        //System.out.println(shoppingCart.getTotal());
        //System.out.println(shoppingCart.orderString());
        
        
        Order thisOrder = new Order(shoppingCart, "Pending", 00001);
        thisOrder.displayOrder();
        System.out.println(thisOrder.getSummary());
        //System.out.println(thisOrder.getOrderCost());
        
        TransactionProcessor tp1 = new TransactionProcessor(1, us1, thisOrder);
        tp1.performTransaction();
        System.out.println(us1.toString());
        tp1.produceReport();
        */
       
    }
    
}
